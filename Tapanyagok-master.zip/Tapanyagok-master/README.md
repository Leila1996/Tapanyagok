# Tápanyagok

Tápanyag kalória és tápérték lekérdező ASP.NET Core Web API back-end és Vue.js front-end weboldal.
Kiegészítve jQuery kliens oldali megoldással.

## Hivatkozások

- [DataTables](https://datatables.net/)
- [DataTables Server-side processing](https://datatables.net/manual/server-side)
- [DataTables Vue3 component](https://datatables.net/manual/vue)
- [DataTables C# Model](https://learn.microsoft.com/en-us/answers/questions/898164/how-use-web-api-pagination-sorting-and-search-in-j)
- [Enable CORS in ASP.NET Core](https://learn.microsoft.com/en-us/aspnet/core/security/cors)
- [jQuery CDN](https://releases.jquery.com/)